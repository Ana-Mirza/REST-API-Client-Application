#include <stdio.h>      /* printf, sprintf */
#include <stdlib.h>     /* exit, atoi, malloc, free */
#include <unistd.h>     /* read, write, close */
#include <string.h>     /* memcpy, memset */
#include <sys/socket.h> /* socket, connect */
#include <netinet/in.h> /* struct sockaddr_in, struct sockaddr */
#include <netdb.h>      /* struct hostent, gethostbyname */
#include <arpa/inet.h>
#include "helpers.h"
#include "requests.h"

int main(int argc, char *argv[])
{
    char *message;
    char *response;
    int sockfd;

        
    // Ex 1.1: GET dummy from main server
    sockfd = open_connection("34.254.242.81", 8080, AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        printf("error sockfd");
        return -1;
    }

    char* request = compute_get_request("34.254.242.81:8080", "/api/v1/dummy", NULL, NULL, 0);
    // printf("%s\n", request);

    send_to_server(sockfd, request);
    response = receive_from_server(sockfd);
    // printf("%s\n", response);

    // Ex 1.2: POST dummy and print response from main server
    char *body_data[] = {"username=student", "password=student"};
    request = compute_post_request("34.254.242.81:8080", "/api/v1/dummy", "application/x-www-form-urlencoded", body_data, 2, NULL, 0);
    // printf("%s\n", request);

    send_to_server(sockfd, request);
    response = receive_from_server(sockfd);
    // printf("%s\n", response);

    // Ex 2: Login into main server
    request = compute_post_request("34.254.242.81:8080", "/api/v1/auth/login", "application/x-www-form-urlencoded", body_data, 2, NULL, 0);
    // printf("%s\n", request);

    send_to_server(sockfd, request);
    response = receive_from_server(sockfd);
    // printf("%s\n", response);

    // Ex 3: GET weather key from main server
    char *cookies[] = {"connect.sid=s%3AETNuEIyL5POJAwNApdMQGZNQc1mwEIqj.lxL1ekOqSoohsqUgh%2FudyhbBE%2FhB7tffAd7R9MBJFco",
                       "Path=/", "HttpOnly"};
    request = compute_get_request("34.254.242.81:8080", "/api/v1/weather/key", NULL, cookies, 3);
    // printf("%s\n", request);

    send_to_server(sockfd, request);
    response = receive_from_server(sockfd);
    // printf("%s\n", response);

    // Ex 4: GET weather data from OpenWeather API
    close(sockfd);
    sockfd = open_connection("82.196.7.246", 80, AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        printf("error sockfd");
        return -1;
    }

    request = compute_get_request("82.196.7.246:80", "/data/2.5/weather", "lat=44&lon=100&appid=b912dd495585fbf756dc6d8f415a7649", NULL, 0);
    printf("%s\n", request);

    send_to_server(sockfd, request);
    response = receive_from_server(sockfd);
    printf("%s\n", response);

    // Ex 5: POST weather data for verification to main server
    char *body[] = {response};
    request = compute_post_request("34.254.242.81:80", "/api/v1/weather/44/100", "application/x-www-form-urlencoded", body, 1, NULL, 0);
    printf("%s\n", request);

    send_to_server(sockfd, request);
    response = receive_from_server(sockfd);
    printf("%s\n", response);


    // Ex 6: Logout from main server

    // BONUS: make the main server return "Already logged in!"

    // free the allocated data at the end!

    return 0;
}
